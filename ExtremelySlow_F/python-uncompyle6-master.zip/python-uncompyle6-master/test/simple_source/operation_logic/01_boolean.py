1 and 0
1 or 0
