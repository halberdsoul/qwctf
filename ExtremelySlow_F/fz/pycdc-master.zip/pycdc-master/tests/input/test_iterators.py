for i in range(20):
    print i,
print

for i in range(10):
    print i,
else:
    print 'The End'
