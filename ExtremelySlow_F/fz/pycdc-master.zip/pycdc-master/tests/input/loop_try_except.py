async def myFunc():
    async for b in c:
        try:
            STUFF
        except MyException:
            running = False

for b in c:
    stuff
    try:
        STUFF
    except MyException:
        running = False

while a:
    stuff
    try:
        STUFF
    except MyException:
        running = False